// Data Store
const appData = {
  kpiMetrics: [
    { name: "Total Fraud Attempts", value: 2847, unit: "cases", trend: "up", trendPercent: 12.3, status: "critical" },
    { name: "Fraud Detection Rate", value: 94.2, unit: "%", trend: "up", trendPercent: 3.1, status: "good" },
    { name: "Loss Exposure", value: 1250000, unit: "$", trend: "down", trendPercent: 8.7, status: "warning" },
    { name: "Daily Alerts", value: 423, unit: "alerts", trend: "up", trendPercent: 5.2, status: "warning" },
    { name: "False Positive Rate", value: 2.1, unit: "%", trend: "down", trendPercent: 1.5, status: "good" },
    { name: "Active Risk Tx", value: 87, unit: "transactions", trend: "up", trendPercent: 6.8, status: "critical" }
  ],
  fraudDistribution: [
    { range: "Very High (>90%)", count: 342, percentage: 12.0, color: "#ef4444" },
    { range: "High (70-90%)", count: 568, percentage: 20.0, color: "#f97316" },
    { range: "Medium (40-70%)", count: 846, percentage: 29.8, color: "#f59e0b" },
    { range: "Low (<40%)", count: 1091, percentage: 38.2, color: "#10b981" }
  ],
  alertsTrend: [
    { hour: "00:00", total: 15, blocked: 3, review: 8 },
    { hour: "04:00", total: 18, blocked: 4, review: 9 },
    { hour: "08:00", total: 35, blocked: 8, review: 15 },
    { hour: "12:00", total: 52, blocked: 12, review: 24 },
    { hour: "16:00", total: 48, blocked: 10, review: 22 },
    { hour: "20:00", total: 38, blocked: 7, review: 18 },
    { hour: "23:59", total: 22, blocked: 5, review: 12 }
  ],
  lossExposure: [
    { category: "Credit Card Fraud", amount: 500000, percentage: 40, color: "#ef4444" },
    { category: "Account Takeover", amount: 312500, percentage: 25, color: "#f97316" },
    { category: "Wire Transfer Fraud", amount: 250000, percentage: 20, color: "#f59e0b" },
    { category: "Money Laundering", amount: 187500, percentage: 15, color: "#f3a726" }
  ],
  regions: [
    { name: "North America", code: "NA", fraudCount: 23, loss: 450000, riskLevel: "high", transactions: 85432 },
    { name: "Europe", code: "EU", fraudCount: 18, loss: 380000, riskLevel: "high", transactions: 62145 },
    { name: "Asia", code: "AS", fraudCount: 12, loss: 290000, riskLevel: "medium", transactions: 54321 },
    { name: "Africa", code: "AF", fraudCount: 5, loss: 85000, riskLevel: "low", transactions: 12543 },
    { name: "South America", code: "SA", fraudCount: 8, loss: 145000, riskLevel: "medium", transactions: 28934 }
  ],
  recentAlerts: [
    { id: "alert_001", type: "High Risk Transaction", severity: "critical", timestamp: "2 minutes ago", transactionId: "TXN_847291", amount: 15000, description: "Transaction amount exceeds usual pattern by 300%" },
    { id: "alert_002", type: "Account Takeover", severity: "critical", timestamp: "5 minutes ago", transactionId: "TXN_847290", amount: 8500, description: "Login from new device and location combination" },
    { id: "alert_003", type: "Velocity Alert", severity: "high", timestamp: "8 minutes ago", transactionId: "TXN_847289", amount: 3200, description: "5 transactions in 10 minutes from same account" },
    { id: "alert_004", type: "Geographic Anomaly", severity: "high", timestamp: "12 minutes ago", transactionId: "TXN_847288", amount: 5600, description: "Transaction from different country within 2 hours" },
    { id: "alert_005", type: "New Device Alert", severity: "medium", timestamp: "15 minutes ago", transactionId: "TXN_847287", amount: 2100, description: "First transaction from unrecognized device" },
    { id: "alert_006", type: "Behavioral Anomaly", severity: "medium", timestamp: "18 minutes ago", transactionId: "TXN_847286", amount: 4500, description: "Purchase category differs from user profile" }
  ],
  fraudNetwork: {
    nodes: [
      { id: "user_001", type: "user", name: "Known Fraudster A", risk: "critical" },
      { id: "user_002", type: "user", name: "Suspicious User B", risk: "high" },
      { id: "user_003", type: "user", name: "Suspicious User C", risk: "high" },
      { id: "account_001", type: "account", name: "Account A", risk: "critical" },
      { id: "account_002", type: "account", name: "Account B", risk: "high" },
      { id: "account_003", type: "account", name: "Account C", risk: "high" },
      { id: "device_001", type: "device", name: "Device 1", risk: "high" },
      { id: "device_002", type: "device", name: "Device 2", risk: "medium" }
    ],
    edges: [
      { source: "user_001", target: "account_001", strength: "strong" },
      { source: "user_001", target: "device_001", strength: "strong" },
      { source: "user_002", target: "account_002", strength: "medium" },
      { source: "user_002", target: "device_001", strength: "strong" },
      { source: "user_003", target: "account_003", strength: "medium" },
      { source: "account_001", target: "device_002", strength: "medium" }
    ]
  }
};

// Chart instances
let charts = {};

// Initialize application
function init() {
  setupEventListeners();
  updateTime();
  setInterval(updateTime, 1000);
  initializeCharts();
  renderAlerts();
  renderFraudNetwork();
  startRealTimeUpdates();
}

// Setup event listeners
function setupEventListeners() {
  // Theme toggle
  document.getElementById('themeToggle').addEventListener('click', toggleTheme);
  
  // Sidebar toggle
  document.getElementById('sidebarToggle').addEventListener('click', toggleSidebar);
  
  // Filter controls
  document.getElementById('applyFilters').addEventListener('click', applyFilters);
  document.getElementById('resetFilters').addEventListener('click', resetFilters);
  
  // Modal close buttons
  document.getElementById('modalClose').addEventListener('click', () => closeModal('transactionModal'));
  document.getElementById('regionModalClose').addEventListener('click', () => closeModal('regionModal'));
  
  // Close modal on backdrop click
  document.getElementById('transactionModal').addEventListener('click', (e) => {
    if (e.target.id === 'transactionModal') closeModal('transactionModal');
  });
  document.getElementById('regionModal').addEventListener('click', (e) => {
    if (e.target.id === 'regionModal') closeModal('regionModal');
  });
  
  // Region cards
  document.querySelectorAll('.region-card').forEach(card => {
    card.addEventListener('click', () => {
      const region = card.dataset.region;
      showRegionDetails(region);
    });
  });
}

// Update time display
function updateTime() {
  const now = new Date();
  const timeString = now.toLocaleTimeString('en-US', { hour12: false });
  document.getElementById('currentTime').textContent = timeString;
}

// Toggle theme
function toggleTheme() {
  const currentTheme = document.documentElement.getAttribute('data-color-scheme');
  const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
  document.documentElement.setAttribute('data-color-scheme', newTheme);
}

// Toggle sidebar
function toggleSidebar() {
  const sidebar = document.getElementById('alertsSidebar');
  const mainContainer = document.querySelector('.main-container');
  sidebar.classList.toggle('collapsed');
  mainContainer.classList.toggle('sidebar-collapsed');
}

// Initialize charts
function initializeCharts() {
  createFraudDistributionChart();
  createAlertsTrendChart();
  createLossExposureChart();
}

// Fraud Distribution Chart
function createFraudDistributionChart() {
  const ctx = document.getElementById('fraudDistributionChart').getContext('2d');
  charts.fraudDistribution = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: appData.fraudDistribution.map(d => d.range),
      datasets: [{
        label: 'Transaction Count',
        data: appData.fraudDistribution.map(d => d.count),
        backgroundColor: appData.fraudDistribution.map(d => d.color),
        borderRadius: 6,
        borderWidth: 0
      }]
    },
    options: {
      indexAxis: 'y',
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: {
          callbacks: {
            label: function(context) {
              return `Count: ${context.parsed.x} (${appData.fraudDistribution[context.dataIndex].percentage}%)`;
            }
          }
        }
      },
      scales: {
        x: {
          beginAtZero: true,
          grid: { color: 'rgba(119, 124, 124, 0.1)' },
          ticks: { color: '#626c71' }
        },
        y: {
          grid: { display: false },
          ticks: { color: '#626c71', font: { size: 11 } }
        }
      },
      animation: {
        duration: 1000,
        easing: 'easeOutQuart'
      }
    }
  });
}

// Alerts Trend Chart
function createAlertsTrendChart() {
  const ctx = document.getElementById('alertsTrendChart').getContext('2d');
  charts.alertsTrend = new Chart(ctx, {
    type: 'line',
    data: {
      labels: appData.alertsTrend.map(d => d.hour),
      datasets: [
        {
          label: 'Total Alerts',
          data: appData.alertsTrend.map(d => d.total),
          borderColor: '#06b6d4',
          backgroundColor: 'rgba(6, 182, 212, 0.1)',
          fill: true,
          tension: 0.4,
          borderWidth: 2,
          pointRadius: 4,
          pointHoverRadius: 6
        },
        {
          label: 'Blocked',
          data: appData.alertsTrend.map(d => d.blocked),
          borderColor: '#ef4444',
          backgroundColor: 'rgba(239, 68, 68, 0.1)',
          fill: true,
          tension: 0.4,
          borderWidth: 2,
          pointRadius: 4,
          pointHoverRadius: 6
        },
        {
          label: 'Manual Review',
          data: appData.alertsTrend.map(d => d.review),
          borderColor: '#f59e0b',
          backgroundColor: 'rgba(245, 158, 11, 0.1)',
          fill: true,
          tension: 0.4,
          borderWidth: 2,
          pointRadius: 4,
          pointHoverRadius: 6
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      interaction: {
        mode: 'index',
        intersect: false
      },
      plugins: {
        legend: {
          display: true,
          position: 'top',
          labels: { color: '#626c71', padding: 15, font: { size: 12 } }
        },
        tooltip: {
          backgroundColor: 'rgba(0, 0, 0, 0.8)',
          padding: 12,
          titleColor: '#fff',
          bodyColor: '#fff',
          borderColor: '#06b6d4',
          borderWidth: 1
        }
      },
      scales: {
        x: {
          grid: { color: 'rgba(119, 124, 124, 0.1)' },
          ticks: { color: '#626c71' }
        },
        y: {
          beginAtZero: true,
          grid: { color: 'rgba(119, 124, 124, 0.1)' },
          ticks: { color: '#626c71' }
        }
      },
      animation: {
        duration: 1000,
        easing: 'easeOutQuart'
      }
    }
  });
}

// Loss Exposure Chart
function createLossExposureChart() {
  const ctx = document.getElementById('lossExposureChart').getContext('2d');
  charts.lossExposure = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: appData.lossExposure.map(d => d.category),
      datasets: [{
        data: appData.lossExposure.map(d => d.percentage),
        backgroundColor: appData.lossExposure.map(d => d.color),
        borderWidth: 2,
        borderColor: '#fff'
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          display: true,
          position: 'bottom',
          labels: { color: '#626c71', padding: 15, font: { size: 12 } }
        },
        tooltip: {
          callbacks: {
            label: function(context) {
              const label = context.label || '';
              const value = appData.lossExposure[context.dataIndex];
              return `${label}: $${(value.amount / 1000).toFixed(0)}K (${value.percentage}%)`;
            }
          }
        }
      },
      animation: {
        animateRotate: true,
        animateScale: true,
        duration: 1000,
        easing: 'easeOutQuart'
      }
    }
  });
}

// Render fraud network
function renderFraudNetwork() {
  const svg = document.getElementById('networkSvg');
  const width = svg.clientWidth;
  const height = 400;
  
  // Clear existing content
  svg.innerHTML = '';
  
  // Create positions for nodes
  const positions = {};
  const centerX = width / 2;
  const centerY = height / 2;
  const radius = 120;
  
  appData.fraudNetwork.nodes.forEach((node, i) => {
    const angle = (i / appData.fraudNetwork.nodes.length) * 2 * Math.PI;
    positions[node.id] = {
      x: centerX + radius * Math.cos(angle),
      y: centerY + radius * Math.sin(angle)
    };
  });
  
  // Draw edges
  appData.fraudNetwork.edges.forEach(edge => {
    const source = positions[edge.source];
    const target = positions[edge.target];
    
    const line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
    line.setAttribute('x1', source.x);
    line.setAttribute('y1', source.y);
    line.setAttribute('x2', target.x);
    line.setAttribute('y2', target.y);
    line.setAttribute('stroke', edge.strength === 'strong' ? '#ef4444' : '#f59e0b');
    line.setAttribute('stroke-width', edge.strength === 'strong' ? '2' : '1');
    line.setAttribute('opacity', '0.6');
    svg.appendChild(line);
  });
  
  // Draw nodes
  appData.fraudNetwork.nodes.forEach(node => {
    const pos = positions[node.id];
    let shape, size;
    
    if (node.type === 'user') {
      shape = 'circle';
      size = 20;
    } else if (node.type === 'account') {
      shape = 'rect';
      size = 18;
    } else {
      shape = 'diamond';
      size = 18;
    }
    
    // Draw shape
    let element;
    if (shape === 'circle') {
      element = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
      element.setAttribute('cx', pos.x);
      element.setAttribute('cy', pos.y);
      element.setAttribute('r', size / 2);
    } else if (shape === 'rect') {
      element = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
      element.setAttribute('x', pos.x - size / 2);
      element.setAttribute('y', pos.y - size / 2);
      element.setAttribute('width', size);
      element.setAttribute('height', size);
      element.setAttribute('rx', 2);
    } else {
      element = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
      element.setAttribute('x', pos.x - size / 2);
      element.setAttribute('y', pos.y - size / 2);
      element.setAttribute('width', size);
      element.setAttribute('height', size);
      element.setAttribute('transform', `rotate(45 ${pos.x} ${pos.y})`);
    }
    
    const fillColor = node.risk === 'critical' ? '#ef4444' : node.risk === 'high' ? '#f97316' : '#06b6d4';
    element.setAttribute('fill', fillColor);
    element.setAttribute('stroke', '#fff');
    element.setAttribute('stroke-width', '2');
    element.style.cursor = 'pointer';
    
    // Add hover effect
    element.addEventListener('mouseenter', () => {
      element.setAttribute('stroke-width', '3');
      element.setAttribute('filter', 'drop-shadow(0 0 8px ' + fillColor + ')');
    });
    element.addEventListener('mouseleave', () => {
      element.setAttribute('stroke-width', '2');
      element.setAttribute('filter', 'none');
    });
    
    // Add click handler
    element.addEventListener('click', () => {
      showNodeDetails(node);
    });
    
    svg.appendChild(element);
    
    // Add label
    const text = document.createElementNS('http://www.w3.org/2000/svg', 'text');
    text.setAttribute('x', pos.x);
    text.setAttribute('y', pos.y + size + 15);
    text.setAttribute('text-anchor', 'middle');
    text.setAttribute('fill', '#626c71');
    text.setAttribute('font-size', '11');
    text.textContent = node.name;
    svg.appendChild(text);
  });
}

// Show node details
function showNodeDetails(node) {
  const modalBody = document.getElementById('modalBody');
  modalBody.innerHTML = `
    <div class="detail-grid">
      <div class="detail-item">
        <div class="detail-label">Node ID</div>
        <div class="detail-value">${node.id}</div>
      </div>
      <div class="detail-item">
        <div class="detail-label">Type</div>
        <div class="detail-value">${node.type.toUpperCase()}</div>
      </div>
      <div class="detail-item">
        <div class="detail-label">Name</div>
        <div class="detail-value">${node.name}</div>
      </div>
      <div class="detail-item">
        <div class="detail-label">Risk Level</div>
        <div class="detail-value" style="color: ${node.risk === 'critical' ? '#ef4444' : '#f97316'}">${node.risk.toUpperCase()}</div>
      </div>
    </div>
    <h3 style="margin: 20px 0 10px 0; font-size: 16px;">Connected Entities</h3>
    <div style="background: var(--color-background); padding: 15px; border-radius: 8px; border: 1px solid var(--color-card-border);">
      ${getConnectedEntities(node.id).map(entity => `
        <div style="padding: 8px; border-bottom: 1px solid var(--color-card-border); last-child:border-bottom: none;">
          <strong>${entity.name}</strong> (${entity.type})
        </div>
      `).join('')}
    </div>
  `;
  document.getElementById('transactionModal').classList.add('active');
}

// Get connected entities
function getConnectedEntities(nodeId) {
  const connected = [];
  appData.fraudNetwork.edges.forEach(edge => {
    if (edge.source === nodeId) {
      const target = appData.fraudNetwork.nodes.find(n => n.id === edge.target);
      if (target) connected.push(target);
    } else if (edge.target === nodeId) {
      const source = appData.fraudNetwork.nodes.find(n => n.id === edge.source);
      if (source) connected.push(source);
    }
  });
  return connected;
}

// Render alerts
function renderAlerts() {
  const alertsList = document.getElementById('alertsList');
  alertsList.innerHTML = '';
  
  appData.recentAlerts.forEach(alert => {
    const alertItem = document.createElement('div');
    alertItem.className = `alert-item ${alert.severity}`;
    alertItem.innerHTML = `
      <div class="alert-header">
        <div class="alert-type">${alert.type}</div>
        <div class="alert-severity ${alert.severity}">${alert.severity}</div>
      </div>
      <div class="alert-description">${alert.description}</div>
      <div class="alert-meta">
        <span>${alert.timestamp}</span>
        <span class="alert-amount">$${alert.amount.toLocaleString()}</span>
      </div>
    `;
    alertItem.addEventListener('click', () => showAlertDetails(alert));
    alertsList.appendChild(alertItem);
  });
  
  document.getElementById('alertBadge').textContent = appData.recentAlerts.length;
}

// Show alert details
function showAlertDetails(alert) {
  const modalBody = document.getElementById('modalBody');
  modalBody.innerHTML = `
    <div class="risk-score">
      <div class="risk-score-value">87</div>
      <div class="risk-score-label">Risk Score (High)</div>
    </div>
    <div class="detail-grid">
      <div class="detail-item">
        <div class="detail-label">Transaction ID</div>
        <div class="detail-value">${alert.transactionId}</div>
      </div>
      <div class="detail-item">
        <div class="detail-label">Amount</div>
        <div class="detail-value">$${alert.amount.toLocaleString()}</div>
      </div>
      <div class="detail-item">
        <div class="detail-label">Alert Type</div>
        <div class="detail-value">${alert.type}</div>
      </div>
      <div class="detail-item">
        <div class="detail-label">Severity</div>
        <div class="detail-value" style="color: ${alert.severity === 'critical' ? '#ef4444' : '#f97316'}">${alert.severity.toUpperCase()}</div>
      </div>
      <div class="detail-item">
        <div class="detail-label">User Account</div>
        <div class="detail-value">ACC_${Math.floor(Math.random() * 100000)}</div>
      </div>
      <div class="detail-item">
        <div class="detail-label">Device ID</div>
        <div class="detail-value">DEV_${Math.floor(Math.random() * 100000)}</div>
      </div>
      <div class="detail-item">
        <div class="detail-label">IP Address</div>
        <div class="detail-value">${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}</div>
      </div>
      <div class="detail-item">
        <div class="detail-label">Location</div>
        <div class="detail-value">New York, USA</div>
      </div>
    </div>
    <h3 style="margin: 20px 0 10px 0; font-size: 16px;">Alert Description</h3>
    <div style="background: var(--color-background); padding: 15px; border-radius: 8px; border: 1px solid var(--color-card-border); margin-bottom: 20px;">
      ${alert.description}
    </div>
    <h3 style="margin: 20px 0 10px 0; font-size: 16px;">Recommended Action</h3>
    <div style="background: var(--color-background); padding: 15px; border-radius: 8px; border: 1px solid var(--color-card-border);">
      Based on the risk score and pattern analysis, we recommend immediate manual review or blocking this transaction.
    </div>
    <div class="action-buttons">
      <button class="btn-action btn-block" onclick="handleAction('block', '${alert.id}')">Block Transaction</button>
      <button class="btn-action btn-review" onclick="handleAction('review', '${alert.id}')">Flag for Review</button>
      <button class="btn-action btn-whitelist" onclick="handleAction('whitelist', '${alert.id}')">Whitelist</button>
    </div>
  `;
  document.getElementById('transactionModal').classList.add('active');
}

// Handle action buttons
window.handleAction = function(action, alertId) {
  const actionMessages = {
    block: 'Transaction blocked successfully',
    review: 'Transaction flagged for manual review',
    whitelist: 'Transaction whitelisted'
  };
  
  // Remove alert from list
  const alertIndex = appData.recentAlerts.findIndex(a => a.id === alertId);
  if (alertIndex > -1) {
    appData.recentAlerts.splice(alertIndex, 1);
    renderAlerts();
  }
  
  closeModal('transactionModal');
  
  // Show notification (simple approach)
  alert(actionMessages[action]);
};

// Show region details
function showRegionDetails(regionCode) {
  const region = appData.regions.find(r => r.code === regionCode);
  if (!region) return;
  
  const modalBody = document.getElementById('regionModalBody');
  document.getElementById('regionModalTitle').textContent = `${region.name} - Detailed Analysis`;
  
  modalBody.innerHTML = `
    <div class="detail-grid">
      <div class="detail-item">
        <div class="detail-label">Total Transactions</div>
        <div class="detail-value">${region.transactions.toLocaleString()}</div>
      </div>
      <div class="detail-item">
        <div class="detail-label">Fraud Cases</div>
        <div class="detail-value">${region.fraudCount}</div>
      </div>
      <div class="detail-item">
        <div class="detail-label">Total Loss</div>
        <div class="detail-value">$${(region.loss / 1000).toFixed(0)}K</div>
      </div>
      <div class="detail-item">
        <div class="detail-label">Risk Level</div>
        <div class="detail-value" style="color: ${region.riskLevel === 'high' ? '#ef4444' : region.riskLevel === 'medium' ? '#f59e0b' : '#10b981'}">${region.riskLevel.toUpperCase()}</div>
      </div>
      <div class="detail-item">
        <div class="detail-label">Fraud Rate</div>
        <div class="detail-value">${((region.fraudCount / region.transactions) * 100).toFixed(3)}%</div>
      </div>
      <div class="detail-item">
        <div class="detail-label">Avg Loss/Case</div>
        <div class="detail-value">$${(region.loss / region.fraudCount / 1000).toFixed(1)}K</div>
      </div>
    </div>
    <h3 style="margin: 20px 0 10px 0; font-size: 16px;">Top Fraud Patterns</h3>
    <div style="background: var(--color-background); padding: 15px; border-radius: 8px; border: 1px solid var(--color-card-border); margin-bottom: 15px;">
      <div style="margin-bottom: 10px;">• Account takeover attempts from new devices</div>
      <div style="margin-bottom: 10px;">• Cross-border wire transfer fraud</div>
      <div style="margin-bottom: 10px;">• Credit card payment velocity anomalies</div>
      <div>• Suspicious merchant category codes</div>
    </div>
    <h3 style="margin: 20px 0 10px 0; font-size: 16px;">Recent Transactions</h3>
    <div style="background: var(--color-background); border-radius: 8px; border: 1px solid var(--color-card-border); overflow: hidden;">
      ${generateMockTransactions(region).map((tx, i) => `
        <div style="padding: 12px; border-bottom: ${i < 4 ? '1px solid var(--color-card-border)' : 'none'};">
          <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
            <strong>${tx.id}</strong>
            <span style="color: ${tx.status === 'Blocked' ? '#ef4444' : tx.status === 'Review' ? '#f59e0b' : '#10b981'};">${tx.status}</span>
          </div>
          <div style="font-size: 12px; color: var(--color-text-secondary);">
            ${tx.merchant} • $${tx.amount.toLocaleString()} • ${tx.time}
          </div>
        </div>
      `).join('')}
    </div>
  `;
  
  document.getElementById('regionModal').classList.add('active');
}

// Generate mock transactions
function generateMockTransactions(region) {
  const merchants = ['Amazon', 'Walmart', 'Target', 'Best Buy', 'Apple Store'];
  const statuses = ['Blocked', 'Review', 'Approved', 'Review', 'Blocked'];
  const transactions = [];
  
  for (let i = 0; i < 5; i++) {
    transactions.push({
      id: `TXN_${Math.floor(Math.random() * 1000000)}`,
      merchant: merchants[Math.floor(Math.random() * merchants.length)],
      amount: Math.floor(Math.random() * 5000) + 100,
      status: statuses[i],
      time: `${Math.floor(Math.random() * 12) + 1} hours ago`
    });
  }
  
  return transactions;
}

// Close modal
function closeModal(modalId) {
  document.getElementById(modalId).classList.remove('active');
}

// Apply filters
function applyFilters() {
  const dateRange = document.getElementById('dateRange').value;
  const riskLevel = document.getElementById('riskLevel').value;
  const transactionType = document.getElementById('transactionType').value;
  const region = document.getElementById('regionFilter').value;
  
  // In a real application, this would filter the data and update all charts
  console.log('Applying filters:', { dateRange, riskLevel, transactionType, region });
  
  // Simulate filter application with a visual effect
  document.querySelectorAll('.chart-card').forEach(card => {
    card.style.opacity = '0.5';
    setTimeout(() => {
      card.style.opacity = '1';
    }, 300);
  });
}

// Reset filters
function resetFilters() {
  document.getElementById('dateRange').value = '24h';
  document.getElementById('riskLevel').value = 'all';
  document.getElementById('transactionType').value = 'all';
  document.getElementById('regionFilter').value = 'all';
  applyFilters();
}

// Start real-time updates
function startRealTimeUpdates() {
  // Update KPI values every 5 seconds
  setInterval(() => {
    updateKPIValues();
  }, 5000);
  
  // Add new alert every 10 seconds
  setInterval(() => {
    addNewAlert();
  }, 10000);
  
  // Update charts every 15 seconds
  setInterval(() => {
    updateCharts();
  }, 15000);
}

// Update KPI values
function updateKPIValues() {
  const kpiElements = [
    { id: 'kpi-fraud-attempts', index: 0, format: (v) => v.toLocaleString() },
    { id: 'kpi-detection-rate', index: 1, format: (v) => v.toFixed(1) + '%' },
    { id: 'kpi-loss-exposure', index: 2, format: (v) => '$' + (v / 1000000).toFixed(2) + 'M' },
    { id: 'kpi-daily-alerts', index: 3, format: (v) => Math.floor(v).toLocaleString() },
    { id: 'kpi-false-positive', index: 4, format: (v) => v.toFixed(1) + '%' },
    { id: 'kpi-active-risk', index: 5, format: (v) => Math.floor(v).toLocaleString() }
  ];
  
  kpiElements.forEach(({ id, index, format }) => {
    const element = document.getElementById(id);
    if (element) {
      const currentValue = appData.kpiMetrics[index].value;
      const variation = (Math.random() - 0.5) * 0.02 * currentValue; // ±1% variation
      const newValue = currentValue + variation;
      appData.kpiMetrics[index].value = newValue;
      
      // Animate the value change
      element.style.transform = 'scale(1.05)';
      element.textContent = format(newValue);
      setTimeout(() => {
        element.style.transform = 'scale(1)';
      }, 200);
    }
  });
}

// Add new alert
function addNewAlert() {
  const alertTypes = ['High Risk Transaction', 'Velocity Alert', 'Geographic Anomaly', 'New Device Alert'];
  const severities = ['critical', 'high', 'medium'];
  const descriptions = [
    'Unusual transaction pattern detected',
    'Multiple transactions in short timeframe',
    'Transaction from unfamiliar location',
    'New device accessing account'
  ];
  
  const newAlert = {
    id: `alert_${Date.now()}`,
    type: alertTypes[Math.floor(Math.random() * alertTypes.length)],
    severity: severities[Math.floor(Math.random() * severities.length)],
    timestamp: 'Just now',
    transactionId: `TXN_${Math.floor(Math.random() * 1000000)}`,
    amount: Math.floor(Math.random() * 15000) + 1000,
    description: descriptions[Math.floor(Math.random() * descriptions.length)]
  };
  
  appData.recentAlerts.unshift(newAlert);
  if (appData.recentAlerts.length > 10) {
    appData.recentAlerts.pop();
  }
  
  renderAlerts();
}

// Update charts with new data
function updateCharts() {
  // Slightly modify the data to simulate real-time updates
  appData.alertsTrend.forEach(point => {
    point.total += Math.floor(Math.random() * 5) - 2;
    point.blocked += Math.floor(Math.random() * 2) - 1;
    point.review += Math.floor(Math.random() * 3) - 1;
    
    // Ensure values don't go negative
    point.total = Math.max(0, point.total);
    point.blocked = Math.max(0, point.blocked);
    point.review = Math.max(0, point.review);
  });
  
  // Update the charts
  if (charts.alertsTrend) {
    charts.alertsTrend.data.datasets[0].data = appData.alertsTrend.map(d => d.total);
    charts.alertsTrend.data.datasets[1].data = appData.alertsTrend.map(d => d.blocked);
    charts.alertsTrend.data.datasets[2].data = appData.alertsTrend.map(d => d.review);
    charts.alertsTrend.update('none');
  }
}

// Initialize on load
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}